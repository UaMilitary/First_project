
import shutil
from pathlib import Path


def create_backup(path, file_name, employee_residence):
    with open(f"{path}\{file_name}", 'wb') as fh:
        employee_list = ""
        for key, value in employee_residence.items():
            employee_list += f"{key} {value}\n"
            fh.write(employee_list.encode())
    archive = shutil.make_archive('backup_folder', 'zip', path)
    return archive
        
employee_dict_list = {'Michael': 'Canada', 'John':'USA', 'Liza': 'Australia'}
print(create_backup(str(Path(r"E:\Py_Projects\First_project\06_hw")), "base_1.txt", employee_dict_list))